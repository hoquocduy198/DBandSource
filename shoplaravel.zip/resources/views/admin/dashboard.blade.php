@extends('admin_layout')
@section('admin_content')
<h3>Chào mừng bạn !!!</h3>

@endsection
