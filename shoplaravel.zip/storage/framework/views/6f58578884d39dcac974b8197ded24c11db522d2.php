<p>Hi, Xin chào mình là Admin</p>
<p>Bạn đã đặt hàng thành công </p>
<p>Thông tin đơn hàng : </p>
<p>Đỉa chỉ khách hàng : <?php echo e($data['diachi']); ?></p>
<p>Tổng tiền thanh toán : <?php echo e($data['giatong']); ?></p>
<p>Chi tiết đơn hàng</p>
<?php $__currentLoopData = $data['chitiet']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<p>Tên món hàng: <?php echo e($item->oder_name); ?></p>
<p>Giá món hàng: <?php echo e($item->oder_price); ?></p>
<p>Số lượng món hàng: <?php echo e($item->order_qty); ?></p>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>