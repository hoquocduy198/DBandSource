<?php $__env->startSection('content'); ?>

<form action="<?php echo e(route('login')); ?>" method="post" class="beta-form-checkout">
<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
    <div class="row">
    <div class="col-sm-3"></div>
    <?php if(Session::has('thanhcong')): ?>
    <div class="alert alert-success"><?php echo e(Session::get('thanhcong')); ?></div>
    <?php endif; ?>
    <?php if(count($errors)>0): ?>
            
    <div class="alert alert-danger">
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <br>
    <?php echo e($err); ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php endif; ?>

    <div class="col-sm-6">
        <h4>ĐĂNG NHẬP</h4>
        <div class="space20">&nbsp;</div>

        <div class="form-block">
                <label for="email">Email address : </label>
                <input type="email" name="email" required>
        </div>
        <div class="form-block">
                <label for="password">Password : </label>
                <input type="password" name="password" required>
        </div>
        <div class="form-block">
                <button type="submit" class="btn btn-primary">Đăng Nhập</button>
        </div>
        <div class="col-sm-3"></div>   
    </div>    
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>